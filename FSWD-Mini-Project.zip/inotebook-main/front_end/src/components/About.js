import React from 'react'

const About = () => {

  return ( 
    <div className='mt-10'>
      this is About
    </div>
  )
}

export default About
